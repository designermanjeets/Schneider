cwise-parser
============
New preprocessor for cwise. Not intended to be run by itself (use [cwise](https://github.com/scijs/cwise) instead).

[![build status](https://secure.travis-ci.org/scijs/cwise-parser.png)](http://travis-ci.org/scijs/cwise-parser)

# Install
Install using [npm](https://www.npmjs.com/):

    npm install cwise-parser

# License
(c) 2013 Mikola Lysenko. MIT License.
