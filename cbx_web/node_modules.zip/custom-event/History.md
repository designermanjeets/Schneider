
1.0.0 / 2015-01-07
==================

  * Makefile: whitespace fix
  * enable Travis-CI testing
  * add .gitignore file
  * test: add test cases
  * initial commit
